import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final dbPath = p.join(await getDatabasesPath(), 'peeka_tasks.db');
    _database = await openDatabase(dbPath, version: 1, onCreate: (db, version) async {
      await db.execute("""CREATE TABLE tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        due_at TEXT,
        reminder_at TEXT,
        is_completed INTEGER NOT NULL DEFAULT 0,
        notification_id INTEGER NOT NULL
      )""");
      await db.execute('CREATE INDEX tasks_completed_idx ON tasks(is_completed)');
    });
    return _database!;
  }
}
