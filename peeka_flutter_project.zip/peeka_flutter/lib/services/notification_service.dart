import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();
  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;
    tzdata.initializeTimeZones();
    try {
      final zone = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(zone.name));
    } catch (e) {
      // Fallback avoids blocking app startup; scheduled times use the package default zone.
      debugPrint('Could not read device timezone: $e');
    }
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(const InitializationSettings(android: android));
    _initialized = true;
  }

  Future<bool?> requestPermission() async {
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    return android?.requestNotificationsPermission();
  }

  Future<bool?> areNotificationsEnabled() async {
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    return android?.areNotificationsEnabled();
  }

  Future<bool?> canScheduleExactAlarms() async {
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    return android?.canScheduleExactNotifications();
  }

  Future<bool?> requestExactAlarmPermission() async {
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    return android?.requestExactAlarmsPermission();
  }

  Future<void> schedule({required int id, required String title, required DateTime when}) async {
    await initialize();
    if (!when.isAfter(DateTime.now())) {
      await cancel(id);
      return;
    }
    final scheduled = tz.TZDateTime.from(when, tz.local);
    const details = NotificationDetails(android: AndroidNotificationDetails(
      'peeka_task_reminders', 'Task reminders',
      channelDescription: 'Reminders for tasks you create in Peeka',
      importance: Importance.max, priority: Priority.high,
      category: AndroidNotificationCategory.reminder,
    ));
    try {
      await _plugin.zonedSchedule(id, title, 'Your task is due now.', scheduled, details,
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        payload: 'task:$id');
    } catch (e) {
      debugPrint('Could not schedule reminder $id: $e');
      rethrow;
    }
  }

  Future<void> showTestNotification() async {
    await initialize();
    const details = NotificationDetails(android: AndroidNotificationDetails(
      'peeka_task_reminders', 'Task reminders',
      channelDescription: 'Reminders for tasks you create in Peeka',
      importance: Importance.max, priority: Priority.high,
    ));
    await _plugin.show(2147483000, 'Peeka test reminder', 'Notifications are working on this device.', details);
  }

  Future<void> cancel(int id) async => _plugin.cancel(id);
}
