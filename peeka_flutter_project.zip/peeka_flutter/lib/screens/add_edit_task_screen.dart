import 'package:flutter/material.dart';
import '../models/task_model.dart';
import '../utils/date_time_utils.dart';

class AddEditTaskScreen extends StatefulWidget {
  const AddEditTaskScreen({super.key, this.task});
  final TaskModel? task;
  @override
  State<AddEditTaskScreen> createState() => _AddEditTaskScreenState();
}
class _AddEditTaskScreenState extends State<AddEditTaskScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _title;
  late final TextEditingController _description;
  DateTime? _dueAt; DateTime? _reminderAt; bool _reminderEnabled = false;
  @override
  void initState() { super.initState(); _title = TextEditingController(text: widget.task?.title ?? ''); _description = TextEditingController(text: widget.task?.description ?? ''); _dueAt = widget.task?.dueAt; _reminderAt = widget.task?.reminderAt; _reminderEnabled = _reminderAt != null; }
  @override
  void dispose() { _title.dispose(); _description.dispose(); super.dispose(); }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final value = await showDatePicker(context: context, initialDate: _dueAt ?? now, firstDate: DateTime(now.year - 1), lastDate: DateTime(now.year + 10));
    if (value != null && mounted) setState(() { _dueAt = DateTime(value.year, value.month, value.day, _dueAt?.hour ?? 23, _dueAt?.minute ?? 59); if (_reminderAt != null) _reminderAt = DateTime(value.year, value.month, value.day, _reminderAt!.hour, _reminderAt!.minute); });
  }
  Future<void> _pickReminder() async {
    final now = DateTime.now(); final base = _reminderAt ?? _dueAt ?? now;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(base));
    if (time != null && mounted) setState(() { _reminderEnabled = true; final date = _dueAt ?? DateTime.now(); _reminderAt = DateTime(date.year, date.month, date.day, time.hour, time.minute); });
  }
  void _save() {
    if (!_formKey.currentState!.validate()) return;
    if (_reminderEnabled && _reminderAt != null && !_reminderAt!.isAfter(DateTime.now())) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Choose a reminder time in the future.'))); return;
    }
    final existing = widget.task;
    final result = TaskModel(id: existing?.id, title: _title.text.trim(), description: _description.text.trim(),
      createdAt: existing?.createdAt ?? DateTime.now(), dueAt: _dueAt, reminderAt: _reminderEnabled ? _reminderAt : null,
      isCompleted: existing?.isCompleted ?? false, notificationId: existing?.notificationId ?? DateTime.now().microsecondsSinceEpoch.remainder(2000000000));
    Navigator.pop(context, result);
  }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(widget.task == null ? 'New task' : 'Edit task')),
    body: SafeArea(child: Form(key: _formKey, child: ListView(padding: const EdgeInsets.all(20), children: [
      Text('What do you need to do?', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 18),
      TextFormField(controller: _title, autofocus: true, textCapitalization: TextCapitalization.sentences, maxLength: 90,
        decoration: const InputDecoration(labelText: 'Task title', hintText: 'e.g. Finish assignment', prefixIcon: Icon(Icons.check_circle_outline)),
        validator: (v) => v == null || v.trim().isEmpty ? 'Please enter a task title.' : null),
      const SizedBox(height: 10), TextFormField(controller: _description, minLines: 3, maxLines: 5, textCapitalization: TextCapitalization.sentences,
        decoration: const InputDecoration(labelText: 'Description (optional)', alignLabelWithHint: true, prefixIcon: Icon(Icons.notes))),
      const SizedBox(height: 24), Text('Schedule', style: Theme.of(context).textTheme.titleMedium), const SizedBox(height: 10),
      ListTile(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), tileColor: Theme.of(context).cardColor,
        leading: const Icon(Icons.calendar_month_outlined), title: const Text('Due date'), subtitle: Text(DateTimeUtils.date(_dueAt)), trailing: const Icon(Icons.chevron_right), onTap: _pickDate),
      const SizedBox(height: 10), SwitchListTile(tileColor: Theme.of(context).cardColor, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        secondary: const Icon(Icons.notifications_active_outlined), title: const Text('Reminder'), subtitle: Text(_reminderEnabled && _reminderAt != null ? '${DateTimeUtils.date(_reminderAt)} · ${DateTimeUtils.time(_reminderAt!)}' : 'Get a notification at a chosen time'),
        value: _reminderEnabled, onChanged: (v) => setState(() { _reminderEnabled = v; if (v && _reminderAt == null) _reminderAt = _dueAt ?? DateTime.now().add(const Duration(hours: 1)); })),
      if (_reminderEnabled) ...[const SizedBox(height: 8), OutlinedButton.icon(onPressed: _pickReminder, icon: const Icon(Icons.schedule), label: Text(_reminderAt == null ? 'Choose reminder time' : 'Change time · ${DateTimeUtils.time(_reminderAt!)}'))],
      const SizedBox(height: 28), FilledButton.icon(onPressed: _save, icon: const Icon(Icons.check), label: const Padding(padding: EdgeInsets.symmetric(vertical: 14), child: Text('Save task'))),
    ]))));
}
