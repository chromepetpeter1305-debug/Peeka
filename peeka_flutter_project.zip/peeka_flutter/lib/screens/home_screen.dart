import 'package:flutter/material.dart';
import '../models/task_model.dart';
import '../repositories/task_repository.dart';
import '../services/notification_service.dart';
import '../theme/app_theme.dart';
import '../utils/date_time_utils.dart';
import '../widgets/peeka_logo.dart';
import '../widgets/task_card.dart';
import '../widgets/task_summary_card.dart';
import 'add_edit_task_screen.dart';

enum TaskFilter { all, pending, completed, overdue }
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.onOpenSettings});
  final VoidCallback onOpenSettings;
  @override State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  final TaskRepository _repository = TaskRepository();
  List<TaskModel> _tasks = []; bool _loading = true; String _search = ''; TaskFilter _filter = TaskFilter.all;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async { try { final tasks = await _repository.getAll(); if (mounted) setState(() { _tasks = tasks; _loading = false; }); } catch (e) { if (mounted) setState(() => _loading = false); debugPrint('Task load failed: $e'); } }
  List<TaskModel> get _visibleTasks => _tasks.where((t) {
    final matchesSearch = t.title.toLowerCase().contains(_search.toLowerCase());
    final matchesFilter = switch (_filter) { TaskFilter.all => true, TaskFilter.pending => !t.isCompleted, TaskFilter.completed => t.isCompleted, TaskFilter.overdue => DateTimeUtils.isOverdue(t.dueAt, t.isCompleted) };
    return matchesSearch && matchesFilter;
  }).toList();
  Future<void> _addOrEdit([TaskModel? task]) async {
    final result = await Navigator.push<TaskModel>(context, MaterialPageRoute(builder: (_) => AddEditTaskScreen(task: task)));
    if (result == null || !mounted) return;
    try {
      if (task == null) {
        final id = await _repository.insert(result);
        final saved = TaskModel(id: id, title: result.title, description: result.description, createdAt: result.createdAt, dueAt: result.dueAt, reminderAt: result.reminderAt, isCompleted: result.isCompleted, notificationId: result.notificationId);
        if (saved.reminderAt != null) { await NotificationService.instance.requestPermission(); await NotificationService.instance.schedule(id: saved.notificationId, title: saved.title, when: saved.reminderAt!); }
      } else {
        await _repository.update(result);
        await NotificationService.instance.cancel(result.notificationId);
        if (!result.isCompleted && result.reminderAt != null && result.reminderAt!.isAfter(DateTime.now())) await NotificationService.instance.schedule(id: result.notificationId, title: result.title, when: result.reminderAt!);
      }
      await _load();
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Task saved, but reminder update failed: $e'))); await _load(); }
  }
  Future<void> _toggle(TaskModel task, bool completed) async {
    final updated = task.copyWith(isCompleted: completed);
    try { await _repository.update(updated); if (completed) { await NotificationService.instance.cancel(task.notificationId); } else if (updated.reminderAt != null && updated.reminderAt!.isAfter(DateTime.now())) { await NotificationService.instance.schedule(id: updated.notificationId, title: updated.title, when: updated.reminderAt!); } await _load(); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not update task: $e'))); }
  }
  Future<void> _delete(TaskModel task) async {
    final yes = await showDialog<bool>(context: context, builder: (context) => AlertDialog(title: const Text('Delete task?'), content: Text('“${task.title}” will be removed from this device.'), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete'))]));
    if (yes != true) return;
    try { await _repository.delete(task.id!); await NotificationService.instance.cancel(task.notificationId); await _load(); } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not delete task: $e'))); }
  }
  @override Widget build(BuildContext context) {
    final completed = _tasks.where((t) => t.isCompleted).length; final pending = _tasks.length - completed;
    return Scaffold(floatingActionButton: FloatingActionButton.extended(onPressed: () => _addOrEdit(), icon: const Icon(Icons.add), label: const Text('Add task')),
      body: SafeArea(child: RefreshIndicator(onRefresh: _load, child: CustomScrollView(slivers: [
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(20, 18, 20, 8), child: Row(children: [const PeekaLogo(), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Peeka', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)), Text('A little progress, every day.', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppTheme.secondary))])), IconButton(onPressed: widget.onOpenSettings, tooltip: 'Settings', icon: const Icon(Icons.settings_outlined))]))),
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(_greeting(), style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)), const SizedBox(height: 5), Text('Let’s make today count.', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppTheme.secondary)),
          const SizedBox(height: 20), Row(children: [TaskSummaryCard(label: 'Total', count: _tasks.length, icon: Icons.list_alt_rounded, tint: AppTheme.purple), const SizedBox(width: 10), TaskSummaryCard(label: 'Pending', count: pending, icon: Icons.hourglass_bottom_rounded, tint: const Color(0xFFF59E0B)), const SizedBox(width: 10), TaskSummaryCard(label: 'Done', count: completed, icon: Icons.check_circle_outline, tint: const Color(0xFF22C55E))]),
          const SizedBox(height: 22), TextField(onChanged: (v) => setState(() => _search = v), decoration: const InputDecoration(hintText: 'Search your tasks', prefixIcon: Icon(Icons.search), isDense: true)),
          const SizedBox(height: 14), SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [for (final item in [(TaskFilter.all,'All tasks'),(TaskFilter.pending,'Pending'),(TaskFilter.completed,'Completed'),(TaskFilter.overdue,'Overdue')]) Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(label: Text(item.$2), selected: _filter == item.$1, onSelected: (_) => setState(() => _filter = item.$1)))])),
          const SizedBox(height: 8),
        ]))),
        if (_loading) const SliverFillRemaining(child: Center(child: CircularProgressIndicator()))
        else if (_visibleTasks.isEmpty) SliverFillRemaining(hasScrollBody: false, child: Center(child: Padding(padding: const EdgeInsets.all(32), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(_tasks.isEmpty ? Icons.event_note_rounded : Icons.search_off_rounded, size: 64, color: AppTheme.purple), const SizedBox(height: 16), Text(_tasks.isEmpty ? 'Nothing on your list yet' : 'No matching tasks', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 8), Text(_tasks.isEmpty ? 'Add a task and Peeka will help you keep track.' : 'Try another search or filter.', textAlign: TextAlign.center, style: const TextStyle(color: AppTheme.secondary)), if (_tasks.isEmpty) ...[const SizedBox(height: 18), FilledButton.icon(onPressed: () => _addOrEdit(), icon: const Icon(Icons.add), label: const Text('Create your first task'))]]))))
        else SliverPadding(padding: const EdgeInsets.fromLTRB(20, 8, 20, 100), sliver: SliverList(delegate: SliverChildBuilderDelegate((context, index) { final task = _visibleTasks[index]; return TaskCard(task: task, onToggle: (v) => _toggle(task, v), onEdit: () => _addOrEdit(task), onDelete: () => _delete(task)); }, childCount: _visibleTasks.length))),
      ]))));
  }
  String _greeting() { final hour = DateTime.now().hour; if (hour < 12) return 'Good morning ☀️'; if (hour < 17) return 'Good afternoon'; return 'Good evening'; }
}
