import 'package:flutter/material.dart';
import '../services/notification_service.dart';
import '../theme/app_theme.dart';
import '../widgets/peeka_logo.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, required this.currentMode});
  final ThemeMode currentMode;
  @override State<SettingsScreen> createState() => _SettingsScreenState();
}
class _SettingsScreenState extends State<SettingsScreen> {
  bool? _notificationsEnabled; bool _busy = false;
  Future<void> _refresh() async { final value = await NotificationService.instance.areNotificationsEnabled(); if (mounted) setState(() => _notificationsEnabled = value); }
  @override void initState() { super.initState(); _refresh(); }
  Future<void> _test() async { setState(() => _busy = true); try { await NotificationService.instance.requestPermission(); await NotificationService.instance.showTestNotification(); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Test notification sent (if permission is enabled).'))); } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not send notification: $e'))); } finally { if (mounted) { setState(() => _busy = false); _refresh(); } } }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Settings')), body: ListView(padding: const EdgeInsets.all(20), children: [
    Row(children: [const PeekaLogo(size: 54), const SizedBox(width: 14), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Peeka', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)), const Text('Make time for what matters')])]),
    const SizedBox(height: 28), Text('NOTIFICATIONS', style: Theme.of(context).textTheme.labelSmall?.copyWith(color: AppTheme.purple, letterSpacing: 1.3)), const SizedBox(height: 8),
    ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.notifications_outlined), title: const Text('Permission status'), subtitle: Text(_notificationsEnabled == null ? 'Checking…' : _notificationsEnabled! ? 'Notifications are enabled' : 'Notifications are disabled'), trailing: Icon(_notificationsEnabled == true ? Icons.check_circle : Icons.info_outline, color: _notificationsEnabled == true ? Colors.green : AppTheme.secondary)),
    FilledButton.icon(onPressed: _busy ? null : _test, icon: const Icon(Icons.notification_add_outlined), label: Text(_busy ? 'Sending…' : 'Send test notification')),
    const SizedBox(height: 24), Text('APPEARANCE', style: Theme.of(context).textTheme.labelSmall?.copyWith(color: AppTheme.purple, letterSpacing: 1.3)), const SizedBox(height: 8),
    RadioListTile<ThemeMode>(contentPadding: EdgeInsets.zero, value: ThemeMode.dark, groupValue: widget.currentMode, title: const Text('Dark theme'), onChanged: (v) => Navigator.pop(context, v)),
    RadioListTile<ThemeMode>(contentPadding: EdgeInsets.zero, value: ThemeMode.light, groupValue: widget.currentMode, title: const Text('Light theme'), onChanged: (v) => Navigator.pop(context, v)),
    RadioListTile<ThemeMode>(contentPadding: EdgeInsets.zero, value: ThemeMode.system, groupValue: widget.currentMode, title: const Text('Use device setting'), onChanged: (v) => Navigator.pop(context, v)),
    const SizedBox(height: 24), Text('ABOUT', style: Theme.of(context).textTheme.labelSmall?.copyWith(color: AppTheme.purple, letterSpacing: 1.3)),
    const ListTile(contentPadding: EdgeInsets.zero, leading: Icon(Icons.info_outline), title: Text('About Peeka'), subtitle: Text('A simple, private task manager. Your tasks are stored locally on this device.')),
    const ListTile(contentPadding: EdgeInsets.zero, leading: Icon(Icons.verified_outlined), title: Text('Version'), subtitle: Text('1.0.0')),
    const SizedBox(height: 12), Text('Reminder delivery depends on Android notification permissions, alarm settings, and device power-management policies.', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppTheme.secondary)),
  ]));
}
