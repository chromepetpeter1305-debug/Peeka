import 'package:flutter/material.dart';
import 'app.dart';
import 'services/notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await NotificationService.instance.initialize();
  } catch (error, stack) {
    debugPrint('Notification initialization failed: $error\n$stack');
  }
  runApp(const PeekaApp());
}
