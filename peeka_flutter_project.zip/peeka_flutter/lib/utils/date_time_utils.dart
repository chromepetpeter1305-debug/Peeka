import 'package:intl/intl.dart';

class DateTimeUtils {
  static String date(DateTime? value) => value == null ? 'No due date' : DateFormat('EEE, d MMM').format(value);
  static String time(DateTime value) => DateFormat.jm().format(value);
  static bool isOverdue(DateTime? dueAt, bool completed, {DateTime? now}) =>
      !completed && dueAt != null && dueAt.isBefore(now ?? DateTime.now());
}
