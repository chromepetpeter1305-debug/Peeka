import 'package:flutter/material.dart';

class AppTheme {
  static const purple = Color(0xFF8B5CF6);
  static const background = Color(0xFF0B0B12);
  static const surface = Color(0xFF171722);
  static const secondary = Color(0xFFA1A1AA);

  static ThemeData get dark => _build(Brightness.dark, background, surface, Colors.white);
  static ThemeData get light => _build(Brightness.light, const Color(0xFFF7F6FC), Colors.white, const Color(0xFF171722));
  static ThemeData _build(Brightness brightness, Color bg, Color card, Color text) {
    final scheme = ColorScheme.fromSeed(seedColor: purple, brightness: brightness).copyWith(primary: purple, surface: card);
    return ThemeData(useMaterial3: true, brightness: brightness, colorScheme: scheme,
      scaffoldBackgroundColor: bg, cardColor: card,
      appBarTheme: AppBarTheme(backgroundColor: bg, foregroundColor: text, elevation: 0, centerTitle: false),
      textTheme: ThemeData(brightness: brightness).textTheme.apply(bodyColor: text, displayColor: text),
      inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: card,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: purple))),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(backgroundColor: purple, foregroundColor: Colors.white),
      navigationBarTheme: NavigationBarThemeData(backgroundColor: card, indicatorColor: purple.withValues(alpha: .18)),
    );
  }
}
