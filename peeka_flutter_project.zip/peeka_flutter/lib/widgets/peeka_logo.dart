import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class PeekaLogo extends StatelessWidget {
  const PeekaLogo({super.key, this.size = 42});
  final double size;
  @override
  Widget build(BuildContext context) => Container(
    width: size, height: size,
    decoration: BoxDecoration(color: AppTheme.purple, borderRadius: BorderRadius.circular(size * .28)),
    child: Icon(Icons.checklist_rounded, color: Colors.white, size: size * .66),
  );
}
