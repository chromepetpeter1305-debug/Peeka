import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class TaskSummaryCard extends StatelessWidget {
  const TaskSummaryCard({super.key, required this.label, required this.count, required this.icon, required this.tint});
  final String label; final int count; final IconData icon; final Color tint;
  @override
  Widget build(BuildContext context) => Expanded(child: Container(
    padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Theme.of(context).cardColor, borderRadius: BorderRadius.circular(18)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: tint, size: 21), const SizedBox(height: 12),
      Text('$count', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
      Text(label, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppTheme.secondary)),
    ]),
  ));
}
