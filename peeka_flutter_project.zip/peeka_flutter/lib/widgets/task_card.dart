import 'package:flutter/material.dart';
import '../models/task_model.dart';
import '../utils/date_time_utils.dart';
import '../theme/app_theme.dart';

class TaskCard extends StatelessWidget {
  const TaskCard({super.key, required this.task, required this.onToggle, required this.onEdit, required this.onDelete});
  final TaskModel task; final ValueChanged<bool> onToggle; final VoidCallback onEdit; final VoidCallback onDelete;
  @override
  Widget build(BuildContext context) {
    final overdue = DateTimeUtils.isOverdue(task.dueAt, task.isCompleted);
    return Container(margin: const EdgeInsets.only(bottom: 10), decoration: BoxDecoration(
      color: Theme.of(context).cardColor, borderRadius: BorderRadius.circular(18),
      border: overdue ? Border.all(color: const Color(0xFFEF4444).withValues(alpha: .7)) : null),
      child: Padding(padding: const EdgeInsets.fromLTRB(10, 8, 4, 8), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Checkbox(value: task.isCompleted, onChanged: (v) => onToggle(v ?? false), activeColor: AppTheme.purple),
        Expanded(child: Padding(padding: const EdgeInsets.only(top: 9), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(task.title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600,
            decoration: task.isCompleted ? TextDecoration.lineThrough : null, color: task.isCompleted ? AppTheme.secondary : null)),
          if (task.description.trim().isNotEmpty) ...[const SizedBox(height: 4), Text(task.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppTheme.secondary))],
          const SizedBox(height: 9), Wrap(spacing: 12, runSpacing: 4, children: [
            Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.calendar_today_outlined, size: 13, color: overdue ? const Color(0xFFEF4444) : AppTheme.secondary), const SizedBox(width: 5), Text(DateTimeUtils.date(task.dueAt), style: TextStyle(fontSize: 12, color: overdue ? const Color(0xFFEF4444) : AppTheme.secondary))]),
            if (task.reminderAt != null) Row(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.notifications_none, size: 14, color: AppTheme.secondary), const SizedBox(width: 4), Text(DateTimeUtils.time(task.reminderAt!), style: const TextStyle(fontSize: 12, color: AppTheme.secondary))]),
            if (overdue) const Text('OVERDUE', style: TextStyle(fontSize: 10, color: Color(0xFFEF4444), fontWeight: FontWeight.bold)),
          ]),
        ]))),
        PopupMenuButton<String>(onSelected: (v) { if (v == 'edit') onEdit(); if (v == 'delete') onDelete(); }, itemBuilder: (_) => const [
          PopupMenuItem(value: 'edit', child: ListTile(leading: Icon(Icons.edit_outlined), title: Text('Edit'), contentPadding: EdgeInsets.zero)),
          PopupMenuItem(value: 'delete', child: ListTile(leading: Icon(Icons.delete_outline), title: Text('Delete'), contentPadding: EdgeInsets.zero)),
        ]),
      ])),
    );
  }
}
