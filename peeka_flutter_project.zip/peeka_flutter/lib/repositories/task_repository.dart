import 'package:sqflite/sqflite.dart';
import '../models/task_model.dart';
import '../services/database_service.dart';

class TaskRepository {
  TaskRepository({DatabaseService? databaseService}) : _databaseService = databaseService ?? DatabaseService.instance;
  final DatabaseService _databaseService;

  Future<List<TaskModel>> getAll() async {
    final db = await _databaseService.database;
    final rows = await db.query('tasks', orderBy: 'is_completed ASC, due_at IS NULL, due_at ASC, created_at DESC');
    return rows.map(TaskModel.fromMap).toList();
  }

  Future<int> insert(TaskModel task) async => (await _databaseService.database).insert('tasks', task.toMap()..remove('id'));

  Future<void> update(TaskModel task) async {
    if (task.id == null) throw ArgumentError('Cannot update a task without an ID.');
    await (await _databaseService.database).update('tasks', task.toMap(), where: 'id = ?', whereArgs: [task.id]);
  }

  Future<void> delete(int id) async => (await _databaseService.database).delete('tasks', where: 'id = ?', whereArgs: [id]);
}
