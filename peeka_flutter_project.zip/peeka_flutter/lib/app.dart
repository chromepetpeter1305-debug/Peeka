import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/settings_screen.dart';
import 'theme/app_theme.dart';

class PeekaApp extends StatefulWidget {
  const PeekaApp({super.key});
  @override
  State<PeekaApp> createState() => _PeekaAppState();
}

class _PeekaAppState extends State<PeekaApp> {
  ThemeMode _themeMode = ThemeMode.dark;
  void _setTheme(ThemeMode mode) => setState(() => _themeMode = mode);

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Peeka',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        darkTheme: AppTheme.dark,
        themeMode: _themeMode,
        home: HomeScreen(onOpenSettings: () async {
          final mode = await Navigator.of(context).push<ThemeMode>(
            MaterialPageRoute(builder: (_) => SettingsScreen(currentMode: _themeMode)),
          );
          if (mode != null) _setTheme(mode);
        }),
      );
}
