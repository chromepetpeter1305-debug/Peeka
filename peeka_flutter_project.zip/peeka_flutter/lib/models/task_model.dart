class TaskModel {
  const TaskModel({
    required this.id,
    required this.title,
    required this.description,
    required this.createdAt,
    this.dueAt,
    this.reminderAt,
    required this.isCompleted,
    required this.notificationId,
  });

  final int? id;
  final String title;
  final String description;
  final DateTime createdAt;
  final DateTime? dueAt;
  final DateTime? reminderAt;
  final bool isCompleted;
  final int notificationId;

  TaskModel copyWith({String? title, String? description, DateTime? dueAt,
      bool clearDueAt = false, DateTime? reminderAt, bool clearReminderAt = false,
      bool? isCompleted, int? id, int? notificationId}) => TaskModel(
    id: id ?? this.id,
    title: title ?? this.title,
    description: description ?? this.description,
    createdAt: createdAt,
    dueAt: clearDueAt ? null : (dueAt ?? this.dueAt),
    reminderAt: clearReminderAt ? null : (reminderAt ?? this.reminderAt),
    isCompleted: isCompleted ?? this.isCompleted,
    notificationId: notificationId ?? this.notificationId,
  );

  Map<String, Object?> toMap() => {
    'id': id, 'title': title, 'description': description,
    'created_at': createdAt.toIso8601String(),
    'due_at': dueAt?.toIso8601String(),
    'reminder_at': reminderAt?.toIso8601String(),
    'is_completed': isCompleted ? 1 : 0,
    'notification_id': notificationId,
  };

  factory TaskModel.fromMap(Map<String, Object?> map) => TaskModel(
    id: map['id'] as int?, title: map['title'] as String,
    description: (map['description'] as String?) ?? '',
    createdAt: DateTime.parse(map['created_at'] as String),
    dueAt: map['due_at'] == null ? null : DateTime.parse(map['due_at'] as String),
    reminderAt: map['reminder_at'] == null ? null : DateTime.parse(map['reminder_at'] as String),
    isCompleted: (map['is_completed'] as int? ?? 0) == 1,
    notificationId: map['notification_id'] as int,
  );
}
