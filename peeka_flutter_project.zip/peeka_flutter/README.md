# Peeka — Flutter task manager

Peeka is an Android-first task manager built with Flutter/Dart. Tasks are stored locally in SQLite. Reminders use local notifications; no account or internet connection is required.

## Requirements
- Flutter stable (Dart 3.4+; the notification package may require a newer Flutter SDK depending on the resolved release)
- Android Studio or VS Code with Flutter and Android SDK tools
- Android device/emulator, API 23+

## Run
1. Extract the ZIP and open the `peeka_flutter` folder in Android Studio or VS Code.
2. Run `flutter doctor` and resolve Android toolchain issues.
3. Run `flutter pub get`.
4. Run `dart run flutter_launcher_icons` to generate Android launcher icon files from `assets/branding/peeka_launcher.png`.
5. Connect an Android phone with USB debugging enabled, or start an emulator.
6. Run `flutter run`.

## Build a debug APK
From the project root:

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
```

APK output: `build/app/outputs/flutter-apk/app-debug.apk`.

## Install on Android phone
- Copy `app-debug.apk` to your phone and open it, then approve installation if Android asks.
- Alternatively, with USB debugging enabled run `flutter install`.

## Reminders and Android limitations
- On Android 13+, Peeka requests notification permission. If denied, task saving still works, but notifications may not appear.
- Peeka schedules reminders as inexact alarms to avoid requiring exact-alarm access for routine task reminders. Android may delay these during Doze/battery saver. If you require minute-accurate alarms, review the Android exact-alarm permission policy and update the app to request special access explicitly; Google Play restricts use of `USE_EXACT_ALARM`.
- Some manufacturers aggressively restrict background activity. If reminders are late, allow notifications and background activity for Peeka in system settings and review battery optimization settings.
- The boot receiver is configured to let the notification plugin restore scheduled reminders after reboot. Actual restoration depends on Android/OEM behavior and the plugin's runtime permissions.
- Notification test is available in Settings.
- The app catches notification initialization/scheduling errors and keeps the task list usable, but notification delivery cannot be guaranteed on every device.

## Project layout

```text
lib/
  main.dart
  app.dart
  models/task_model.dart
  repositories/task_repository.dart
  screens/add_edit_task_screen.dart
  screens/home_screen.dart
  screens/settings_screen.dart
  services/database_service.dart
  services/notification_service.dart
  theme/app_theme.dart
  utils/date_time_utils.dart
  widgets/peeka_logo.dart
  widgets/task_card.dart
  widgets/task_summary_card.dart
assets/branding/
  peeka_logo.svg
  peeka_logo.png
  peeka_launcher.png
android/ ...
test/task_model_test.dart
```

## Validation status
This project archive was assembled in an environment without the Flutter SDK/Android SDK, so `flutter pub get`, `flutter analyze`, `flutter test`, and APK building have **not** been run here. Run the commands above locally and fix any SDK/version-specific issues surfaced by your installed Flutter toolchain.
