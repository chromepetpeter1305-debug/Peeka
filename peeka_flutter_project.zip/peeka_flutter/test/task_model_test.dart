import 'package:flutter_test/flutter_test.dart';
import 'package:peeka/models/task_model.dart';

void main() {
  test('TaskModel serializes and restores task fields', () {
    final task = TaskModel(id: 7, title: 'Read', description: 'Chapter one', createdAt: DateTime(2026, 1, 2, 10), dueAt: DateTime(2026, 1, 3), reminderAt: DateTime(2026, 1, 3, 9), isCompleted: true, notificationId: 77);
    final restored = TaskModel.fromMap(task.toMap());
    expect(restored.id, 7); expect(restored.title, 'Read'); expect(restored.description, 'Chapter one');
    expect(restored.isCompleted, isTrue); expect(restored.notificationId, 77); expect(restored.reminderAt, task.reminderAt);
  });
  test('copyWith toggles completion without changing identity', () {
    final task = TaskModel(id: 2, title: 'Study', description: '', createdAt: DateTime(2026), isCompleted: false, notificationId: 22);
    final done = task.copyWith(isCompleted: true);
    expect(done.isCompleted, isTrue); expect(done.id, task.id); expect(done.notificationId, task.notificationId);
  });
}
